/* $OpenBSD: rc4_locl.h,v 1.3 2014/06/12 15:49:30 deraadt Exp $ */

#ifndef HEADER_RC4_LOCL_H
#define HEADER_RC4_LOCL_H
#endif
